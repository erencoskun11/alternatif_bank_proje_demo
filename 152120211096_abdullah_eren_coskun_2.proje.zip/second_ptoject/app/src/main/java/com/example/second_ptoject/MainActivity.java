package com.example.second_ptoject;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MainActivity extends AppCompatActivity {

    SeekBar seek1, seek2, seek3;
    TextView val1, val2, val3, textRgb;
    ConstraintLayout layout1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seek1 = findViewById(R.id.seek1);
        seek2 = findViewById(R.id.seek2);
        seek3 = findViewById(R.id.seek3);
        val1 = findViewById(R.id.val1);
        val2 = findViewById(R.id.val2);
        val3 = findViewById(R.id.val3);
        textRgb = findViewById(R.id.textRgb);
        layout1 = findViewById(R.id.layout1);

        seek1.setMax(255);
        seek2.setMax(255);
        seek3.setMax(255);
        seek1.setProgress(255);
        seek2.setProgress(255);
        seek3.setProgress(255);
        updateColor();

        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateColor();
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        };

        seek1.setOnSeekBarChangeListener(listener);
        seek2.setOnSeekBarChangeListener(listener);
        seek3.setOnSeekBarChangeListener(listener);
    }

    private void updateColor() {
        int r = seek1.getProgress();
        int g = seek2.getProgress();
        int b = seek3.getProgress();
        val1.setText(String.valueOf(r));
        val2.setText(String.valueOf(g));
        val3.setText(String.valueOf(b));
        layout1.setBackgroundColor(Color.rgb(r, g, b));
        textRgb.setText("rgb = " + r + "," + g + "," + b);
    }
}
